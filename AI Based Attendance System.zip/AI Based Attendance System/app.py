# app.py
from flask import Flask, render_template, request, redirect, session, send_file, flash
import os
from werkzeug.utils import secure_filename
from excel_tracker import ExcelTracker
from datetime import datetime
import threading
import csv
import pandas as pd
import datetime as dt

app = Flask(__name__)
app.secret_key = 'your_secret_key_here'
UPLOAD_FOLDER = 'images'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

tracker = ExcelTracker()

@app.route('/')
def home():
    return render_template('login.html')

@app.route('/login', methods=['POST'])
def login():
    username = request.form['username'].strip().upper()
    password = request.form['password'].strip()
    print(f"🔐 Attempted login → Username: {username}, Password: {password}")

    if username == 'ADMIN' and password == 'admin123':
        print("✅ Admin login successful")
        session['admin'] = True
        return redirect('/admin')

    # Student login
    found_student = False
    correct_section = None
    
    # First check if student exists in any section
    print(f"🔍 Checking sections: {tracker.section_students}")
    for section, students in tracker.section_students.items():
        print(f"🔍 Checking section {section}: {students}")
        if username in students:
            found_student = True
            correct_section = section
            print(f"✅ Student {username} found in {section}")
            break

    if not found_student:
        print(f"❌ Student {username} not found in any section")
        flash("Invalid credentials")
        return redirect('/')

    # Get student's DOB
    student_dob = tracker.get_student_dob(username)
    print(f"🔍 Student DOB from storage: {student_dob}")

    # Try different DOB formats
    dob_formats = []
    if student_dob:
        dob_formats.extend([
            student_dob,  # Original format
            student_dob.replace('-', ''),  # Remove hyphens
            f"{student_dob[6:10]}-{student_dob[3:5]}-{student_dob[:2]}",  # YYYY-MM-DD
            f"{student_dob[8:10]}{student_dob[3:5]}{student_dob[:2]}",  # DDMMYYYY
        ])
    
    print(f"🔍 Trying DOB formats: {dob_formats}")
    
    if student_dob is None:  # If DOB is not set yet
        print(f"⚠️ No DOB set for student {username}, setting initial DOB")
        tracker.update_student_dob(username, password)  # Set the password as DOB
        student_dob = password
        dob_formats = [password]
    
    # Check all possible formats
    if any(dob == password for dob in dob_formats):
        print(f"✅ Student {username} found in {correct_section} with correct DOB")
        session['student'] = username
        session['section'] = correct_section
        return redirect('/student')
    else:
        print(f"❌ Incorrect DOB for student {username}. Expected formats: {dob_formats}, Got: {password}")
        flash("Invalid credentials")
        return redirect('/')

@app.route('/admin')
def admin_dashboard():
    if not session.get('admin'):
        return redirect('/')
    return render_template('admin_dashboard.html', sections=tracker.section_students)

@app.route('/student')
def student_dashboard():
    if not session.get('student'):
        return redirect('/')
    student = session['student']
    section = session['section']
    attendance_file = f"{section} attendance.csv"
    timetable_file = f"timetable/{section}_timetable.csv"
    records = []

    # Load attendance
    if os.path.exists(attendance_file):
        with open(attendance_file, newline='') as f:
            reader = list(csv.reader(f))
            headers = reader[0]
            for row in reader[1:]:
                if row[0] == student:
                    records = list(zip(headers[1:], row[1:]))
                    break

    # Get current subject
    current_subject = None
    current_time = dt.datetime.now()
    current_day = current_time.strftime('%A')
    timetable_data = None

    period_ranges = {
        'Period 1': (9.0, 10.0),
        'Period 2': (10.0, 11.0),
        'Period 3': (11.0, 12.0),
        'Period 4': (12.0, 13.0),
        'Period 5': (13.0, 14.0),
        'Period 6': (14.0, 15.0),
        'Period 7': (15.0, 16.0),
        'Period 8': (23.0, 24.0),
    }

    now_hour = current_time.hour + current_time.minute / 60.0
    print(f"🕒 now_hour = {now_hour:.2f}")
    print(f"📅 Current Day: {current_day}")

    if os.path.exists(timetable_file):
        print(f"📄 Reading timetable from: {timetable_file}")
        df = pd.read_csv(timetable_file)
        timetable_data = df.set_index('Day').to_dict(orient='index')
        print(f"📘 Timetable row for today: {timetable_data.get(current_day)}")

        for period, (start, end) in period_ranges.items():
            if start <= now_hour < end:
                try:
                    current_subject = timetable_data[current_day][period]
                    print(f"✅ Found matching period: {period} → {current_subject}")
                except Exception as e:
                    print(f"⚠️ Could not fetch subject for {period}: {e}")
                    current_subject = None
                break

    if not current_subject:
        print("⚠️ No matching period found or subject is blank.")

    return render_template('student_dashboard.html',
                           student=student,
                           section=section,
                           records=records,
                           subject=current_subject,
                           period_time=f"{now_hour:.2f}",
                           now=current_time.strftime('%I:%M %p'))

@app.route('/upload', methods=['POST'])
def upload():
    if not session.get('admin'):
        return redirect('/')
    file = request.files['image']
    name = request.form['name'].strip().upper()
    section = request.form['section'].strip().upper()
    dob = request.form['dob']  # Get DOB from form

    # Store DOB in tracker
    tracker.update_student_dob(name, dob)
    print(f"✅ Stored DOB for {name}: {dob}")

    section_path = os.path.join(app.config['UPLOAD_FOLDER'], section)
    os.makedirs(section_path, exist_ok=True)
    filename = secure_filename(name + ".jpg")
    file.save(os.path.join(section_path, filename))
    flash("Image uploaded successfully")
    return redirect('/admin')

@app.route('/download/<section>')
def download_csv(section):
    filepath = f"{section} attendance.csv"
    if os.path.exists(filepath):
        return send_file(filepath, as_attachment=True)
    return "File not found", 404

@app.route('/start-camera')
def start_camera():
    from face_recognition_run import main
    threading.Thread(target=main).start()
    return "Started face recognition"

@app.route('/logout')
def logout():
    session.clear()
    return redirect('/')

@app.route('/reset-dob/<student_id>')
def reset_dob(student_id):
    if session.get('admin'):  # Only allow admins to reset DOB
        success = tracker.remove_student_dob(student_id)
        if success:
            flash(f"Successfully removed DOB for {student_id}")
        else:
            flash(f"Could not find DOB for {student_id}")
        return redirect('/admin')
    return redirect('/')

if __name__ == '__main__':
    app.run(debug=True)
