import cv2
import time
from simple_facerec import SimpleFacerec
from excel_tracker import ExcelTracker

def main():
    # Load known faces
    sfr = SimpleFacerec()
    sfr.load_encoding_images("images/")

    # Setup attendance tracker
    tracker = ExcelTracker()
    print("✅ Loaded sections:")
    for section, students in tracker.section_students.items():
        print(f"  {section}: {students}")

    detected = set()

    # Use IP Webcam stream from mobile
    ip_camera_url = "http://192.0.0.4:8080/video"
    print(f"Connecting to mobile camera at: {ip_camera_url}")
    cap = cv2.VideoCapture(ip_camera_url)

    if not cap.isOpened():
        print(f"❌ Error: Could not open video stream at {ip_camera_url}")
        return

    cap.set(cv2.CAP_PROP_FRAME_WIDTH, 640)
    cap.set(cv2.CAP_PROP_FRAME_HEIGHT, 480)

    frame_interval = 1.0  # seconds
    last_time = time.time()

    try:
        while True:
            ret, frame = cap.read()
            if not ret or frame is None:
                print("⚠️ Frame not received. Retrying...")
                continue

            if time.time() - last_time >= frame_interval:
                face_locations, face_names = sfr.detect_known_faces(frame)

                for face_loc, name in zip(face_locations, face_names):
                    if name == "Unknown" or name in detected:
                        continue

                    section = get_section_for_name(name, tracker.section_students)
                    if section:
                        tracker.log_recognition(name, section)
                        detected.add(name)
                        print(f"✅ Marked {name} as Present in {section}")

                    y1, x2, y2, x1 = [v * 2 for v in face_loc]
                    cv2.putText(frame, name, (x1, y1 - 10),
                                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 0, 255), 2)
                    cv2.rectangle(frame, (x1, y1), (x2, y2), (0, 0, 255), 2)

                last_time = time.time()

            cv2.imshow("IP Camera Stream", frame)
            if cv2.waitKey(1) & 0xFF == 27:
                break

    finally:
        cap.release()
        cv2.destroyAllWindows()
        print("\n✅ Attendance finalized.")

def get_section_for_name(name, section_students):
    for section, students in section_students.items():
        if name in students:
            return section
    return None

if __name__ == "__main__":
    main()
