import csv
from datetime import datetime
import os
from pathlib import Path
from collections import defaultdict

class ExcelTracker:
    def __init__(self):
        self.today = datetime.now().strftime("%Y-%m-%d")
        self.recognized_today = defaultdict(set)
        self.image_base_dir = Path(__file__).parent / "images"
        self.section_students = self._load_all_sections()
        self.student_dobs = {}
        self._load_student_dobs()
        self._create_or_update_all_section_files()

    def _load_all_sections(self):
        section_map = {}
        try:
            for section_folder in self.image_base_dir.iterdir():
                if section_folder.is_dir():
                    students = []
                    for file in os.listdir(section_folder):
                        if file.endswith(('.jpg', '.png')):
                            name = os.path.splitext(file)[0]
                            students.append(name)
                    formatted_section = section_folder.name.upper()
                    print(f"Section: {formatted_section} → Students: {students}")
                    section_map[formatted_section] = sorted(students)
        except Exception as e:
            print(f"Error loading sections: {e}")
        return section_map

    def _load_student_dobs(self):
        """Load student DOBs from CSV file"""
        dob_file = "student_dobs.csv"
        print(f"🔍 Loading DOBs from {dob_file}")
        try:
            if os.path.exists(dob_file):
                with open(dob_file, 'r', newline='') as file:
                    reader = csv.reader(file)
                    header = next(reader)  # Skip header
                    print(f"🔍 Header: {header}")
                    for row in reader:
                        if len(row) >= 2:
                            name = row[0].strip().upper()
                            dob = row[1].strip()
                            self.student_dobs[name] = dob
                            print(f"✅ Loaded DOB for {name}: {dob}")
            else:
                print("⚠️ DOB file not found, creating empty dictionary")
        except Exception as e:
            print(f"❌ Error loading DOBs: {e}")
            print(f"❌ Current DOBs: {self.student_dobs}")

    def get_student_dob(self, name):
        """Get student's DOB with debugging"""
        name = name.strip().upper()
        print(f"🔍 Looking up DOB for {name}")
        print(f"🔍 Current DOBs: {self.student_dobs}")
        return self.student_dobs.get(name)

    def _save_student_dobs(self):
        """Save student DOBs to CSV file"""
        dob_file = "student_dobs.csv"
        try:
            with open(dob_file, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(["Name", "DOB"])
                for name, dob in self.student_dobs.items():
                    writer.writerow([name, dob])
        except Exception as e:
            print(f"Error saving DOBs: {e}")

    def get_student_dob(self, name):
        """Get student's DOB"""
        return self.student_dobs.get(name)

    def update_student_dob(self, name, dob):
        """Update or add student's DOB"""
        self.student_dobs[name] = dob
        self._save_student_dobs()

    def remove_student_dob(self, name):
        """Remove a student's DOB"""
        if name in self.student_dobs:
            del self.student_dobs[name]
            self._save_student_dobs()
            return True
        return False

    def _create_or_update_all_section_files(self):
        for section, students in self.section_students.items():
            filename = f"{section} attendance.csv"
            try:
                if not os.path.exists(filename):
                    # File doesn't exist, create with today's header
                    with open(filename, 'w', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow(["Name", self.today, "Time", ""])  # empty column at end
                        for student in students:
                            writer.writerow([student, "Absent", "-", ""])
                else:
                    with open(filename, 'r', newline='') as file:
                        reader = list(csv.reader(file))
                        headers = reader[0]
                        rows = reader[1:]

                    if self.today not in headers:
                        headers.extend([self.today, "Time", ""])
                        for row in rows:
                            row.extend(["Absent", "-", ""])

                    # Add new students if any
                    existing_names = {row[0] for row in rows}
                    for student in students:
                        if student not in existing_names:
                            blank_count = (len(headers) - 1)  # Exclude Name
                            new_row = [student] + [""] * blank_count
                            # Fill today's columns with Absent and "-" correctly
                            new_row[-3] = "Absent"
                            new_row[-2] = "-"
                            rows.append(new_row)

                    # Save file
                    with open(filename, 'w', newline='') as file:
                        writer = csv.writer(file)
                        writer.writerow(headers)
                        writer.writerows(rows)

            except Exception as e:
                print(f"Error updating attendance file {filename}: {e}")

    def log_recognition(self, name, section):
        section = section.upper()
        filename = f"{section} attendance.csv"
        current_time = datetime.now().strftime("%I:%M %p")

        if name in self.recognized_today[section]:
            return

        try:
            with open(filename, 'r', newline='') as file:
                reader = list(csv.reader(file))
                headers = reader[0]
                rows = reader[1:]

            # Locate today's date column
            try:
                status_index = headers.index(self.today)
                time_index = status_index + 1
            except ValueError:
                print(f"Error: Date column for {self.today} not found.")
                return

            for row in rows:
                if row[0] == name:
                    row[status_index] = "Present"
                    row[time_index] = current_time
                    self.recognized_today[section].add(name)
                    break

            with open(filename, 'w', newline='') as file:
                writer = csv.writer(file)
                writer.writerow(headers)
                writer.writerows(rows)

        except Exception as e:
            print(f"Error logging recognition for {section}: {e}")
